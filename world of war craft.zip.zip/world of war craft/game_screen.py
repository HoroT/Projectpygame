import pygame


pygame.display.init()
img = pygame.image.load('interface.jpg')

screen = pygame.display.set_mode(img.get_size(), pygame.FULLSCREEN)
w, h = screen.get_size()
img = pygame.transform.scale(img, (w, h))




class Cursor:
    def __init__(self):
        self.Cursor = pygame.image.load('cursor.png')
        pygame.mouse.set_visible(False)
        self.Cursor = pygame.transform.scale(self.Cursor, (33, 42))

    def render(self, pos):
        screen.blit(self.Cursor, (pos[0], pos[1]))




Arrow, pos = Cursor(), None
running = True
while running:
    screen.fill((0, 0, 0))
    screen.blit(img, (0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEMOTION:
            pos = event.pos
        if event.type == pygame.MOUSEBUTTONUP:
            if (w // 27) < pos[0] < (w // 27) + (w // 5):
                if (h // 171) < pos[1] < (h // 171) + (h // 26):
                    running = False
    
    if pygame.mouse.get_focused():
        Arrow.render(pos)
    
    pygame.display.flip()
pygame.quit()
